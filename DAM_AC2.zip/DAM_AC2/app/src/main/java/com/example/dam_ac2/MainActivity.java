package com.example.dam_ac2;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth mAuth = FirebaseAuth.getInstance();

    private FirebaseFirestore db;
    private EditText edtTitulo, edtAutor, edtPublicacao, edtStatus_Leitura;
    private Spinner spinnerGenero;
    private CheckBox checkBoxFavorito;
    private RecyclerView recyclerLivros;
    private List<Livro> listaLivros = new ArrayList<>();
    private LivroAdapter adapter;
    private Livro livroEditando = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        db = FirebaseFirestore.getInstance();

        edtTitulo = findViewById(R.id.edtTitulo);
        edtAutor = findViewById(R.id.edtAutor);
        spinnerGenero = findViewById(R.id.spinnerGenero);
        edtPublicacao = findViewById(R.id.edtPublicacao);
        edtStatus_Leitura = findViewById(R.id.edtStatus_Leitura);
        checkBoxFavorito = findViewById(R.id.checkBoxFavorito);
        recyclerLivros = findViewById(R.id.recyclerLivros);
        recyclerLivros.setLayoutManager(new LinearLayoutManager(this));
        adapter = new LivroAdapter(listaLivros);
        recyclerLivros.setAdapter(adapter);

        findViewById(R.id.btnSalvar).setOnClickListener(v -> salvarLivro());

        carregarLivros();


    }

    private void salvarLivro() {
        String titulo = edtTitulo.getText().toString();
        String autor = edtAutor.getText().toString();
        String genero = spinnerGenero.getSelectedItem().toString();
        int publicacao = Integer.parseInt(edtPublicacao.getText().toString());
        String status_leitura = edtStatus_Leitura.getText().toString();
        int favorito = checkBoxFavorito.isChecked() ? 1 : 0;

        if (livroEditando == null) {
            Livro livro = new Livro(null, titulo, autor, genero, publicacao, status_leitura, favorito);
            db.collection("livros")
                    .add(livro)
                    .addOnSuccessListener(doc -> {
                        livro.setId(doc.getId());
                        Toast.makeText(this, "Livro salvo!", Toast.LENGTH_SHORT).show();
                        limparCampos();
                        carregarLivros();
                    });
        } else {
            livroEditando.setAutor(autor);
            livroEditando.setGenero(genero);
            livroEditando.setPublicacao(publicacao);
            livroEditando.setStatus_leitura(status_leitura);
            livroEditando.setFavorito(favorito);

            db.collection("livros").document(livroEditando.getId())
                    .set(livroEditando)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Produto atualizado!", Toast.LENGTH_SHORT).show();
                        limparCampos();
                        carregarLivros();
                    });
        }
    }

    private void limparCampos() {
        edtTitulo.setText("");
        edtAutor.setText("");
        edtPublicacao.setText("");
        edtStatus_Leitura.setText("");
        livroEditando = null;
        ((Button) findViewById(R.id.btnSalvar)).setText("Salvar Livro");
    }

    private void carregarLivros() {
        String categoriaSelecionada = spinnerGenero.getSelectedItem().toString();

        db.collection("livros")
                .get()
                .addOnSuccessListener(query -> {
                    listaLivros.clear();
                    for (QueryDocumentSnapshot doc : query) {
                        Livro l = doc.toObject(Livro.class);
                        l.setId(doc.getId());
                        listaLivros.add(l);
                    }
                    adapter.notifyDataSetChanged();
                });

        adapter.setOnItemClickListener(livro -> {
            edtTitulo.setText(livro.getTitulo());
            edtAutor.setText(livro.getAutor());
            spinnerGenero.set(categoriaSelecionada);
            edtEstoque.setText(String.valueOf(produto.getEstoque()));
            produtoEditando = produto;
            ((Button) findViewById(R.id.btnSalvar)).setText("Atualizar Produto");
        });

    }

    public void cadastrarUsuario(View v)
    {
        EditText edtEmail = findViewById(R.id.edtEmail);
        EditText edtSenha = findViewById(R.id.edtSenha);

        mAuth.createUserWithEmailAndPassword(edtEmail.getText().toString(), edtSenha.getText().toString())
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Usuário criado com sucesso", Toast.LENGTH_LONG).show();
                        Log.d("FIREBASE", "Usuário criado com sucesso");
                    } else {
                        Toast.makeText(this, "Erro ao criar usuário: " + task.getException(), Toast.LENGTH_LONG).show();
                        Log.e("FIREBASE", "Erro ao criar usuário", task.getException());
                    }
                });
    }

    public void logarUsuario(View v)
    {
        EditText edtEmail = findViewById(R.id.edtEmail);
        EditText edtSenha = findViewById(R.id.edtSenha);

        mAuth.signInWithEmailAndPassword(edtEmail.getText().toString(), edtSenha.getText().toString())
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Login bem-sucedido", Toast.LENGTH_LONG).show();
                        Log.d("FIREBASE", "Login bem-sucedido");
                    } else {
                        Toast.makeText(this, "Erro no login: " + task.getException(), Toast.LENGTH_LONG).show();
                        Log.e("FIREBASE", "Erro no login", task.getException());
                    }
                });
    }
}